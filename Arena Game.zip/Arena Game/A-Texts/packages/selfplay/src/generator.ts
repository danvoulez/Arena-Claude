/**
 * Synthetic span generator
 */

export function generateSyntheticSpan(seed: any): any {
  // TODO: Implement synthetic generation
  return { id: 'synthetic_1', content: 'Generated span' }
}
