# ArenaLab
Monorepo TypeScript-first. Edge endpoint `/v1/chat/completions`, JSON✯Atomic, trajectory matching, BYOK.
## Comandos
- `pnpm i`
- `pnpm build`
- `pnpm dev` (Cloudflare Worker)
## Pastas
Ver `docs/architecture.md`.
